﻿namespace decisionmaking04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblGrade = new System.Windows.Forms.Label();
            this.lblEnglish = new System.Windows.Forms.Label();
            this.txtEnglish = new System.Windows.Forms.TextBox();
            this.txtMath = new System.Windows.Forms.TextBox();
            this.lblMath = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtScience = new System.Windows.Forms.Label();
            this.txtFilipino = new System.Windows.Forms.TextBox();
            this.lblFilipino = new System.Windows.Forms.Label();
            this.txtHistory = new System.Windows.Forms.TextBox();
            this.lblHistory = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(28, 34);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(77, 30);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(264, 20);
            this.txtName.TabIndex = 1;
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.Location = new System.Drawing.Point(74, 74);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(41, 13);
            this.lblGrade.TabIndex = 2;
            this.lblGrade.Text = "Grades";
            // 
            // lblEnglish
            // 
            this.lblEnglish.AutoSize = true;
            this.lblEnglish.Location = new System.Drawing.Point(28, 113);
            this.lblEnglish.Name = "lblEnglish";
            this.lblEnglish.Size = new System.Drawing.Size(41, 13);
            this.lblEnglish.TabIndex = 3;
            this.lblEnglish.Text = "English";
            // 
            // txtEnglish
            // 
            this.txtEnglish.Location = new System.Drawing.Point(77, 109);
            this.txtEnglish.Name = "txtEnglish";
            this.txtEnglish.Size = new System.Drawing.Size(76, 20);
            this.txtEnglish.TabIndex = 4;
            // 
            // txtMath
            // 
            this.txtMath.Location = new System.Drawing.Point(77, 146);
            this.txtMath.Name = "txtMath";
            this.txtMath.Size = new System.Drawing.Size(76, 20);
            this.txtMath.TabIndex = 6;
            // 
            // lblMath
            // 
            this.lblMath.AutoSize = true;
            this.lblMath.Location = new System.Drawing.Point(28, 150);
            this.lblMath.Name = "lblMath";
            this.lblMath.Size = new System.Drawing.Size(31, 13);
            this.lblMath.TabIndex = 5;
            this.lblMath.Text = "Math";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(77, 182);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(76, 20);
            this.textBox3.TabIndex = 8;
            // 
            // txtScience
            // 
            this.txtScience.AutoSize = true;
            this.txtScience.Location = new System.Drawing.Point(28, 186);
            this.txtScience.Name = "txtScience";
            this.txtScience.Size = new System.Drawing.Size(46, 13);
            this.txtScience.TabIndex = 7;
            this.txtScience.Text = "Science";
            // 
            // txtFilipino
            // 
            this.txtFilipino.Location = new System.Drawing.Point(77, 216);
            this.txtFilipino.Name = "txtFilipino";
            this.txtFilipino.Size = new System.Drawing.Size(76, 20);
            this.txtFilipino.TabIndex = 10;
            // 
            // lblFilipino
            // 
            this.lblFilipino.AutoSize = true;
            this.lblFilipino.Location = new System.Drawing.Point(28, 220);
            this.lblFilipino.Name = "lblFilipino";
            this.lblFilipino.Size = new System.Drawing.Size(39, 13);
            this.lblFilipino.TabIndex = 9;
            this.lblFilipino.Text = "Filipino";
            // 
            // txtHistory
            // 
            this.txtHistory.Location = new System.Drawing.Point(77, 250);
            this.txtHistory.Name = "txtHistory";
            this.txtHistory.Size = new System.Drawing.Size(76, 20);
            this.txtHistory.TabIndex = 12;
            // 
            // lblHistory
            // 
            this.lblHistory.AutoSize = true;
            this.lblHistory.Location = new System.Drawing.Point(28, 254);
            this.lblHistory.Name = "lblHistory";
            this.lblHistory.Size = new System.Drawing.Size(39, 13);
            this.lblHistory.TabIndex = 11;
            this.lblHistory.Text = "History";
            // 
            // lblOutput
            // 
            this.lblOutput.Location = new System.Drawing.Point(202, 158);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(110, 69);
            this.lblOutput.TabIndex = 13;
            this.lblOutput.Text = "OUTPUT";
            this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(31, 289);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(100, 50);
            this.btnGenerate.TabIndex = 14;
            this.btnGenerate.Text = "Generate Average";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 450);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.txtHistory);
            this.Controls.Add(this.lblHistory);
            this.Controls.Add(this.txtFilipino);
            this.Controls.Add(this.lblFilipino);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtScience);
            this.Controls.Add(this.txtMath);
            this.Controls.Add(this.lblMath);
            this.Controls.Add(this.txtEnglish);
            this.Controls.Add(this.lblEnglish);
            this.Controls.Add(this.lblGrade);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblGrade;
        private System.Windows.Forms.Label lblEnglish;
        private System.Windows.Forms.TextBox txtEnglish;
        private System.Windows.Forms.TextBox txtMath;
        private System.Windows.Forms.Label lblMath;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label txtScience;
        private System.Windows.Forms.TextBox txtFilipino;
        private System.Windows.Forms.Label lblFilipino;
        private System.Windows.Forms.TextBox txtHistory;
        private System.Windows.Forms.Label lblHistory;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Button btnGenerate;
    }
}

