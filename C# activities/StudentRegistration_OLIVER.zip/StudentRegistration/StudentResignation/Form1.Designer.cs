﻿namespace StudentResignation
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtlastName = new TextBox();
            label3 = new Label();
            txtfirstName = new TextBox();
            label4 = new Label();
            txmiddleName = new TextBox();
            label5 = new Label();
            rboxMale = new RadioButton();
            rboxFemale = new RadioButton();
            label6 = new Label();
            chooseDay = new ComboBox();
            chooseMonth = new ComboBox();
            chooseYear = new ComboBox();
            btnRegister = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(9, 9);
            label1.Name = "label1";
            label1.Size = new Size(292, 36);
            label1.TabIndex = 0;
            label1.Text = "Student Registration Form";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(12, 45);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 1;
            label2.Text = "Last Name:";
            label2.Click += label2_Click;
            // 
            // txtlastName
            // 
            txtlastName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtlastName.Location = new Point(12, 69);
            txtlastName.Name = "txtlastName";
            txtlastName.Size = new Size(217, 29);
            txtlastName.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(12, 105);
            label3.Name = "label3";
            label3.Size = new Size(80, 20);
            label3.TabIndex = 3;
            label3.Text = "First Name:";
            // 
            // txtfirstName
            // 
            txtfirstName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtfirstName.Location = new Point(12, 129);
            txtfirstName.Name = "txtfirstName";
            txtfirstName.Size = new Size(217, 29);
            txtfirstName.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(12, 163);
            label4.Name = "label4";
            label4.Size = new Size(94, 20);
            label4.TabIndex = 5;
            label4.Text = "Middle Name:";
            // 
            // txmiddleName
            // 
            txmiddleName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txmiddleName.Location = new Point(12, 187);
            txmiddleName.Name = "txmiddleName";
            txmiddleName.Size = new Size(217, 29);
            txmiddleName.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(13, 226);
            label5.Name = "label5";
            label5.Size = new Size(75, 18);
            label5.TabIndex = 7;
            label5.Text = "Gender*";
            // 
            // rboxMale
            // 
            rboxMale.AutoSize = true;
            rboxMale.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            rboxMale.Location = new Point(96, 226);
            rboxMale.Name = "rboxMale";
            rboxMale.Size = new Size(56, 24);
            rboxMale.TabIndex = 8;
            rboxMale.TabStop = true;
            rboxMale.Text = "Male";
            rboxMale.UseVisualStyleBackColor = true;
            // 
            // rboxFemale
            // 
            rboxFemale.AutoSize = true;
            rboxFemale.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            rboxFemale.Location = new Point(154, 226);
            rboxFemale.Name = "rboxFemale";
            rboxFemale.Size = new Size(72, 24);
            rboxFemale.TabIndex = 9;
            rboxFemale.TabStop = true;
            rboxFemale.Text = "Female";
            rboxFemale.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(11, 257);
            label6.Name = "label6";
            label6.Size = new Size(118, 18);
            label6.TabIndex = 10;
            label6.Text = "Date Of Birth*";
            // 
            // chooseDay
            // 
            chooseDay.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            chooseDay.FormattingEnabled = true;
            chooseDay.Location = new Point(15, 283);
            chooseDay.Name = "chooseDay";
            chooseDay.Size = new Size(56, 28);
            chooseDay.TabIndex = 11;
            chooseDay.Text = "Day ";
            // 
            // chooseMonth
            // 
            chooseMonth.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            chooseMonth.FormattingEnabled = true;
            chooseMonth.Location = new Point(75, 283);
            chooseMonth.Name = "chooseMonth";
            chooseMonth.Size = new Size(75, 28);
            chooseMonth.TabIndex = 12;
            chooseMonth.Text = "Month";
            // 
            // chooseYear
            // 
            chooseYear.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            chooseYear.FormattingEnabled = true;
            chooseYear.Location = new Point(154, 283);
            chooseYear.Name = "chooseYear";
            chooseYear.Size = new Size(64, 28);
            chooseYear.TabIndex = 13;
            chooseYear.Text = "Year";
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.Crimson;
            btnRegister.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnRegister.Location = new Point(13, 322);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(152, 44);
            btnRegister.TabIndex = 14;
            btnRegister.Text = "Register Student";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(296, 390);
            Controls.Add(btnRegister);
            Controls.Add(chooseYear);
            Controls.Add(chooseMonth);
            Controls.Add(chooseDay);
            Controls.Add(label6);
            Controls.Add(rboxFemale);
            Controls.Add(rboxMale);
            Controls.Add(label5);
            Controls.Add(txmiddleName);
            Controls.Add(label4);
            Controls.Add(txtfirstName);
            Controls.Add(label3);
            Controls.Add(txtlastName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Student Registration Form";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtlastName;
        private Label label3;
        private TextBox txtfirstName;
        private Label label4;
        private TextBox txmiddleName;
        private Label label5;
        private RadioButton rboxMale;
        private RadioButton rboxFemale;
        private Label label6;
        private ComboBox chooseDay;
        private ComboBox chooseMonth;
        private ComboBox chooseYear;
        private Button btnRegister;
    }
}